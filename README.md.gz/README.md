# felixyangyicheng.github.io  ![felixyangyicheng.github.io](https://img.shields.io/badge/felixyangyicheng-githubio-red) 



## Référence
[![Toolbelt.Blazor.SpeechSynthesis](https://img.shields.io/nuget/v/Toolbelt.Blazor.SpeechSynthesis.svg)![Toolbelt.Blazor.SpeechSynthesis](https://img.shields.io/badge/nuget-Toolbelt.Blazor.SpeechSynthesis-blue)](https://www.nuget.org/packages/Toolbelt.Blazor.SpeechSynthesis/)

 - 🔒 
 - 🔗 
 - 🛠 
 - 🚀 [Que c'est, Manifest V3](https://developer.chrome.com/docs/extensions/develop/migrate/what-is-mv3) - Fichier Manifest V3 chrome extension
 - ⚡️ 

 ## Licence 
[![MIT License](https://img.shields.io/badge/License-MIT-green.svg)](https://choosealicense.com/licenses/mit/) 
.






