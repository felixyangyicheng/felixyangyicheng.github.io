export class Hello {
    hello() {
        ScriptAlert("hello");
    }
    static goodbye() {
        ScriptAlert("goodbye");
    }
}
export var HelloInstance = new Hello();
//# sourceMappingURL=hello.js.map