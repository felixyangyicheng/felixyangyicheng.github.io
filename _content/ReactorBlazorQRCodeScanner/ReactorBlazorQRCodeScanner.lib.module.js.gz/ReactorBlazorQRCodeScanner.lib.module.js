//export function beforeStart(options, extensions) {
//    console.log("ReactorBlazorQRCodeScanner beforeStart");


//}

//export function afterStarted(blazor) {
//    console.log("ReactorBlazorQRCodeScanner afterStarted");
//}