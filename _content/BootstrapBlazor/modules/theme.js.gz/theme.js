﻿import { getPreferredTheme, setTheme } from "./utility.js"

setTheme(getPreferredTheme(), false)
